/********************************************************************************
** Form generated from reading UI file 'form.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM_H
#define UI_FORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QStackedWidget *stackedWidget;
    QWidget *Line;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_8;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *lineEdit_2;
    QComboBox *comboBox_4;
    QComboBox *comboBox_5;
    QComboBox *comboBox_6;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *Polygon;
    QWidget *layoutWidget_3;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton_9;
    QVBoxLayout *verticalLayout_6;
    QLineEdit *lineEdit_3;
    QComboBox *comboBox_7;
    QComboBox *comboBox_8;
    QComboBox *comboBox_9;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(842, 573);
        stackedWidget = new QStackedWidget(Form);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(230, 90, 361, 471));
        Line = new QWidget();
        Line->setObjectName(QString::fromUtf8("Line"));
        layoutWidget_2 = new QWidget(Line);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(90, 90, 231, 401));
        gridLayout_2 = new QGridLayout(layoutWidget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(layoutWidget_2);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));

        gridLayout_2->addWidget(pushButton_8, 1, 0, 1, 2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        lineEdit_2 = new QLineEdit(layoutWidget_2);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        verticalLayout_4->addWidget(lineEdit_2);

        comboBox_4 = new QComboBox(layoutWidget_2);
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        verticalLayout_4->addWidget(comboBox_4);

        comboBox_5 = new QComboBox(layoutWidget_2);
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        verticalLayout_4->addWidget(comboBox_5);

        comboBox_6 = new QComboBox(layoutWidget_2);
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));

        verticalLayout_4->addWidget(comboBox_6);


        gridLayout_2->addLayout(verticalLayout_4, 0, 1, 1, 1);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_5->addWidget(label_5);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_5->addWidget(label_6);

        label_7 = new QLabel(layoutWidget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_5->addWidget(label_7);

        label_8 = new QLabel(layoutWidget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_5->addWidget(label_8);


        gridLayout_2->addLayout(verticalLayout_5, 0, 0, 1, 1);

        stackedWidget->addWidget(Line);
        Polygon = new QWidget();
        Polygon->setObjectName(QString::fromUtf8("Polygon"));
        layoutWidget_3 = new QWidget(Polygon);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(80, 50, 231, 401));
        gridLayout_3 = new QGridLayout(layoutWidget_3);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_9 = new QPushButton(layoutWidget_3);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));

        gridLayout_3->addWidget(pushButton_9, 1, 0, 1, 2);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        lineEdit_3 = new QLineEdit(layoutWidget_3);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));

        verticalLayout_6->addWidget(lineEdit_3);

        comboBox_7 = new QComboBox(layoutWidget_3);
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));

        verticalLayout_6->addWidget(comboBox_7);

        comboBox_8 = new QComboBox(layoutWidget_3);
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));

        verticalLayout_6->addWidget(comboBox_8);

        comboBox_9 = new QComboBox(layoutWidget_3);
        comboBox_9->setObjectName(QString::fromUtf8("comboBox_9"));

        verticalLayout_6->addWidget(comboBox_9);


        gridLayout_3->addLayout(verticalLayout_6, 0, 1, 1, 1);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_9 = new QLabel(layoutWidget_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_7->addWidget(label_9);

        label_10 = new QLabel(layoutWidget_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_7->addWidget(label_10);

        label_11 = new QLabel(layoutWidget_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_7->addWidget(label_11);

        label_12 = new QLabel(layoutWidget_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_7->addWidget(label_12);


        gridLayout_3->addLayout(verticalLayout_7, 0, 0, 1, 1);

        stackedWidget->addWidget(Polygon);
        layoutWidget = new QWidget(Form);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(710, 0, 77, 551));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_5 = new QPushButton(layoutWidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);

        pushButton_4 = new QPushButton(layoutWidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_3 = new QPushButton(layoutWidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);

        pushButton_6 = new QPushButton(layoutWidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        verticalLayout->addWidget(pushButton_6);

        pushButton_7 = new QPushButton(layoutWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        verticalLayout->addWidget(pushButton_7);


        retranslateUi(Form);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QCoreApplication::translate("Form", "Form", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Form", "Build", nullptr));
        label_5->setText(QCoreApplication::translate("Form", "PenWidth:", nullptr));
        label_6->setText(QCoreApplication::translate("Form", "PenStyle:", nullptr));
        label_7->setText(QCoreApplication::translate("Form", "PenCap:", nullptr));
        label_8->setText(QCoreApplication::translate("Form", "PenJoin:", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Form", "Build", nullptr));
        label_9->setText(QCoreApplication::translate("Form", "PenWidth:", nullptr));
        label_10->setText(QCoreApplication::translate("Form", "PenStyle:", nullptr));
        label_11->setText(QCoreApplication::translate("Form", "PenCap:", nullptr));
        label_12->setText(QCoreApplication::translate("Form", "PenJoin:", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Form", "Line", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Form", "Text", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Form", "Rectangle", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Form", "Polygon", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Form", "Elipse", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Form", "Polyline", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_H
