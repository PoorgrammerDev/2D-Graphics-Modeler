/********************************************************************************
** Form generated from reading UI file 'loginapp.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINAPP_H
#define UI_LOGINAPP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginApp
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLineEdit *lineEdit_username;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_password;
    QPushButton *pushButton_login;
    QLabel *label_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LoginApp)
    {
        if (LoginApp->objectName().isEmpty())
            LoginApp->setObjectName(QString::fromUtf8("LoginApp"));
        LoginApp->resize(783, 600);
        centralwidget = new QWidget(LoginApp);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(150, 60, 471, 421));
        widget = new QWidget(groupBox);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(130, 220, 221, 83));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout_2->addWidget(label);

        lineEdit_username = new QLineEdit(widget);
        lineEdit_username->setObjectName(QString::fromUtf8("lineEdit_username"));

        horizontalLayout_2->addWidget(lineEdit_username);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit_password = new QLineEdit(widget);
        lineEdit_password->setObjectName(QString::fromUtf8("lineEdit_password"));

        horizontalLayout->addWidget(lineEdit_password);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);

        pushButton_login = new QPushButton(widget);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));

        verticalLayout_2->addWidget(pushButton_login);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(160, 60, 161, 141));
        label_3->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/paintbrush2.jpg")));
        LoginApp->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginApp);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 783, 21));
        LoginApp->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginApp);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        LoginApp->setStatusBar(statusbar);

        retranslateUi(LoginApp);

        QMetaObject::connectSlotsByName(LoginApp);
    } // setupUi

    void retranslateUi(QMainWindow *LoginApp)
    {
        LoginApp->setWindowTitle(QCoreApplication::translate("LoginApp", "LoginApp", nullptr));
        groupBox->setTitle(QCoreApplication::translate("LoginApp", "Login", nullptr));
        label->setText(QCoreApplication::translate("LoginApp", "UserName:  ", nullptr));
        label_2->setText(QCoreApplication::translate("LoginApp", "Password:   ", nullptr));
        pushButton_login->setText(QCoreApplication::translate("LoginApp", "Login", nullptr));
        label_3->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class LoginApp: public Ui_LoginApp {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINAPP_H
