/********************************************************************************
** Form generated from reading UI file 'dialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOG_H
#define UI_DIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QStackedWidget *stackedWidget;
    QWidget *Line;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_8;
    QVBoxLayout *verticalLayout_4;
    QSpinBox *spinBox;
    QComboBox *comboBox_4;
    QComboBox *comboBox_5;
    QComboBox *comboBox_6;
    QVBoxLayout *verticalLayout_5;
    QLabel *label;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *Text;
    QWidget *layoutWidget_4;
    QGridLayout *gridLayout_3;
    QPushButton *pushButton_11;
    QVBoxLayout *verticalLayout_6;
    QSpinBox *spinBox_3;
    QComboBox *comboBox_7;
    QComboBox *comboBox_8;
    QComboBox *comboBox_9;
    QComboBox *comboBox_21;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QLabel *label_12;
    QWidget *Rectangle;
    QWidget *layoutWidget_5;
    QGridLayout *gridLayout_4;
    QPushButton *pushButton_12;
    QVBoxLayout *verticalLayout_8;
    QSpinBox *spinBox_4;
    QComboBox *comboBox_10;
    QComboBox *comboBox_11;
    QComboBox *comboBox_12;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_13;
    QLabel *label_14;
    QLabel *label_15;
    QLabel *label_16;
    QWidget *Polygon;
    QWidget *layoutWidget_6;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton_13;
    QVBoxLayout *verticalLayout_10;
    QSpinBox *spinBox_5;
    QComboBox *comboBox_13;
    QComboBox *comboBox_14;
    QComboBox *comboBox_15;
    QComboBox *comboBox_19;
    QComboBox *comboBox_20;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_19;
    QLabel *label_20;
    QLabel *label_25;
    QLabel *label_26;
    QWidget *Ellipse;
    QWidget *layoutWidget_7;
    QGridLayout *gridLayout_6;
    QPushButton *pushButton_14;
    QVBoxLayout *verticalLayout_12;
    QSpinBox *spinBox_6;
    QComboBox *comboBox_16;
    QComboBox *comboBox_17;
    QComboBox *comboBox_18;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_21;
    QLabel *label_22;
    QLabel *label_23;
    QLabel *label_24;
    QWidget *Polyline;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_7;
    QVBoxLayout *verticalLayout_2;
    QSpinBox *spinBox_2;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QPushButton *pushButton_6;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QTextBrowser *textBrowser;
    QLabel *label_27;
    QPushButton *pushButton;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(1136, 598);
        stackedWidget = new QStackedWidget(Dialog);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(640, 90, 371, 421));
        Line = new QWidget();
        Line->setObjectName(QString::fromUtf8("Line"));
        layoutWidget_2 = new QWidget(Line);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(140, 20, 231, 401));
        gridLayout_2 = new QGridLayout(layoutWidget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(layoutWidget_2);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));

        gridLayout_2->addWidget(pushButton_8, 1, 0, 1, 2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        spinBox = new QSpinBox(layoutWidget_2);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));

        verticalLayout_4->addWidget(spinBox);

        comboBox_4 = new QComboBox(layoutWidget_2);
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        verticalLayout_4->addWidget(comboBox_4);

        comboBox_5 = new QComboBox(layoutWidget_2);
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        verticalLayout_4->addWidget(comboBox_5);

        comboBox_6 = new QComboBox(layoutWidget_2);
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));

        verticalLayout_4->addWidget(comboBox_6);


        gridLayout_2->addLayout(verticalLayout_4, 0, 1, 1, 1);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label = new QLabel(layoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_5->addWidget(label);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_5->addWidget(label_6);

        label_7 = new QLabel(layoutWidget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_5->addWidget(label_7);

        label_8 = new QLabel(layoutWidget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_5->addWidget(label_8);


        gridLayout_2->addLayout(verticalLayout_5, 0, 0, 1, 1);

        stackedWidget->addWidget(Line);
        Text = new QWidget();
        Text->setObjectName(QString::fromUtf8("Text"));
        layoutWidget_4 = new QWidget(Text);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(140, 10, 231, 401));
        gridLayout_3 = new QGridLayout(layoutWidget_4);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_11 = new QPushButton(layoutWidget_4);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));

        gridLayout_3->addWidget(pushButton_11, 1, 0, 1, 2);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        spinBox_3 = new QSpinBox(layoutWidget_4);
        spinBox_3->setObjectName(QString::fromUtf8("spinBox_3"));

        verticalLayout_6->addWidget(spinBox_3);

        comboBox_7 = new QComboBox(layoutWidget_4);
        comboBox_7->setObjectName(QString::fromUtf8("comboBox_7"));

        verticalLayout_6->addWidget(comboBox_7);

        comboBox_8 = new QComboBox(layoutWidget_4);
        comboBox_8->setObjectName(QString::fromUtf8("comboBox_8"));

        verticalLayout_6->addWidget(comboBox_8);

        comboBox_9 = new QComboBox(layoutWidget_4);
        comboBox_9->setObjectName(QString::fromUtf8("comboBox_9"));

        verticalLayout_6->addWidget(comboBox_9);

        comboBox_21 = new QComboBox(layoutWidget_4);
        comboBox_21->setObjectName(QString::fromUtf8("comboBox_21"));

        verticalLayout_6->addWidget(comboBox_21);


        gridLayout_3->addLayout(verticalLayout_6, 0, 1, 1, 1);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        label_9 = new QLabel(layoutWidget_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        verticalLayout_7->addWidget(label_9);

        label_10 = new QLabel(layoutWidget_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        verticalLayout_7->addWidget(label_10);

        label_11 = new QLabel(layoutWidget_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        verticalLayout_7->addWidget(label_11);

        label_12 = new QLabel(layoutWidget_4);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        verticalLayout_7->addWidget(label_12);


        gridLayout_3->addLayout(verticalLayout_7, 0, 0, 1, 1);

        stackedWidget->addWidget(Text);
        Rectangle = new QWidget();
        Rectangle->setObjectName(QString::fromUtf8("Rectangle"));
        layoutWidget_5 = new QWidget(Rectangle);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(130, 20, 231, 401));
        gridLayout_4 = new QGridLayout(layoutWidget_5);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_12 = new QPushButton(layoutWidget_5);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));

        gridLayout_4->addWidget(pushButton_12, 1, 0, 1, 2);

        verticalLayout_8 = new QVBoxLayout();
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        spinBox_4 = new QSpinBox(layoutWidget_5);
        spinBox_4->setObjectName(QString::fromUtf8("spinBox_4"));

        verticalLayout_8->addWidget(spinBox_4);

        comboBox_10 = new QComboBox(layoutWidget_5);
        comboBox_10->setObjectName(QString::fromUtf8("comboBox_10"));

        verticalLayout_8->addWidget(comboBox_10);

        comboBox_11 = new QComboBox(layoutWidget_5);
        comboBox_11->setObjectName(QString::fromUtf8("comboBox_11"));

        verticalLayout_8->addWidget(comboBox_11);

        comboBox_12 = new QComboBox(layoutWidget_5);
        comboBox_12->setObjectName(QString::fromUtf8("comboBox_12"));

        verticalLayout_8->addWidget(comboBox_12);


        gridLayout_4->addLayout(verticalLayout_8, 0, 1, 1, 1);

        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        label_13 = new QLabel(layoutWidget_5);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        verticalLayout_9->addWidget(label_13);

        label_14 = new QLabel(layoutWidget_5);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        verticalLayout_9->addWidget(label_14);

        label_15 = new QLabel(layoutWidget_5);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        verticalLayout_9->addWidget(label_15);

        label_16 = new QLabel(layoutWidget_5);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_9->addWidget(label_16);


        gridLayout_4->addLayout(verticalLayout_9, 0, 0, 1, 1);

        stackedWidget->addWidget(Rectangle);
        Polygon = new QWidget();
        Polygon->setObjectName(QString::fromUtf8("Polygon"));
        layoutWidget_6 = new QWidget(Polygon);
        layoutWidget_6->setObjectName(QString::fromUtf8("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(140, 10, 231, 401));
        gridLayout_5 = new QGridLayout(layoutWidget_6);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton_13 = new QPushButton(layoutWidget_6);
        pushButton_13->setObjectName(QString::fromUtf8("pushButton_13"));

        gridLayout_5->addWidget(pushButton_13, 1, 0, 1, 2);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        spinBox_5 = new QSpinBox(layoutWidget_6);
        spinBox_5->setObjectName(QString::fromUtf8("spinBox_5"));

        verticalLayout_10->addWidget(spinBox_5);

        comboBox_13 = new QComboBox(layoutWidget_6);
        comboBox_13->setObjectName(QString::fromUtf8("comboBox_13"));

        verticalLayout_10->addWidget(comboBox_13);

        comboBox_14 = new QComboBox(layoutWidget_6);
        comboBox_14->setObjectName(QString::fromUtf8("comboBox_14"));

        verticalLayout_10->addWidget(comboBox_14);

        comboBox_15 = new QComboBox(layoutWidget_6);
        comboBox_15->setObjectName(QString::fromUtf8("comboBox_15"));

        verticalLayout_10->addWidget(comboBox_15);

        comboBox_19 = new QComboBox(layoutWidget_6);
        comboBox_19->setObjectName(QString::fromUtf8("comboBox_19"));

        verticalLayout_10->addWidget(comboBox_19);

        comboBox_20 = new QComboBox(layoutWidget_6);
        comboBox_20->setObjectName(QString::fromUtf8("comboBox_20"));

        verticalLayout_10->addWidget(comboBox_20);


        gridLayout_5->addLayout(verticalLayout_10, 0, 1, 1, 1);

        verticalLayout_11 = new QVBoxLayout();
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        label_17 = new QLabel(layoutWidget_6);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_11->addWidget(label_17);

        label_18 = new QLabel(layoutWidget_6);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        verticalLayout_11->addWidget(label_18);

        label_19 = new QLabel(layoutWidget_6);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        verticalLayout_11->addWidget(label_19);

        label_20 = new QLabel(layoutWidget_6);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        verticalLayout_11->addWidget(label_20);

        label_25 = new QLabel(layoutWidget_6);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        verticalLayout_11->addWidget(label_25);

        label_26 = new QLabel(layoutWidget_6);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        verticalLayout_11->addWidget(label_26);


        gridLayout_5->addLayout(verticalLayout_11, 0, 0, 1, 1);

        stackedWidget->addWidget(Polygon);
        Ellipse = new QWidget();
        Ellipse->setObjectName(QString::fromUtf8("Ellipse"));
        layoutWidget_7 = new QWidget(Ellipse);
        layoutWidget_7->setObjectName(QString::fromUtf8("layoutWidget_7"));
        layoutWidget_7->setGeometry(QRect(140, 10, 231, 401));
        gridLayout_6 = new QGridLayout(layoutWidget_7);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        pushButton_14 = new QPushButton(layoutWidget_7);
        pushButton_14->setObjectName(QString::fromUtf8("pushButton_14"));

        gridLayout_6->addWidget(pushButton_14, 1, 0, 1, 2);

        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        spinBox_6 = new QSpinBox(layoutWidget_7);
        spinBox_6->setObjectName(QString::fromUtf8("spinBox_6"));

        verticalLayout_12->addWidget(spinBox_6);

        comboBox_16 = new QComboBox(layoutWidget_7);
        comboBox_16->setObjectName(QString::fromUtf8("comboBox_16"));

        verticalLayout_12->addWidget(comboBox_16);

        comboBox_17 = new QComboBox(layoutWidget_7);
        comboBox_17->setObjectName(QString::fromUtf8("comboBox_17"));

        verticalLayout_12->addWidget(comboBox_17);

        comboBox_18 = new QComboBox(layoutWidget_7);
        comboBox_18->setObjectName(QString::fromUtf8("comboBox_18"));

        verticalLayout_12->addWidget(comboBox_18);


        gridLayout_6->addLayout(verticalLayout_12, 0, 1, 1, 1);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        label_21 = new QLabel(layoutWidget_7);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        verticalLayout_13->addWidget(label_21);

        label_22 = new QLabel(layoutWidget_7);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        verticalLayout_13->addWidget(label_22);

        label_23 = new QLabel(layoutWidget_7);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        verticalLayout_13->addWidget(label_23);

        label_24 = new QLabel(layoutWidget_7);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        verticalLayout_13->addWidget(label_24);


        gridLayout_6->addLayout(verticalLayout_13, 0, 0, 1, 1);

        stackedWidget->addWidget(Ellipse);
        Polyline = new QWidget();
        Polyline->setObjectName(QString::fromUtf8("Polyline"));
        layoutWidget = new QWidget(Polyline);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(140, 20, 231, 401));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_7 = new QPushButton(layoutWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        gridLayout->addWidget(pushButton_7, 1, 0, 1, 2);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        spinBox_2 = new QSpinBox(layoutWidget);
        spinBox_2->setObjectName(QString::fromUtf8("spinBox_2"));

        verticalLayout_2->addWidget(spinBox_2);

        comboBox = new QComboBox(layoutWidget);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        verticalLayout_2->addWidget(comboBox);

        comboBox_2 = new QComboBox(layoutWidget);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        verticalLayout_2->addWidget(comboBox_2);

        comboBox_3 = new QComboBox(layoutWidget);
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        verticalLayout_2->addWidget(comboBox_3);


        gridLayout->addLayout(verticalLayout_2, 0, 1, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_3->addWidget(label_3);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_3->addWidget(label_5);


        gridLayout->addLayout(verticalLayout_3, 0, 0, 1, 1);

        stackedWidget->addWidget(Polyline);
        layoutWidget_3 = new QWidget(Dialog);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(1020, 30, 77, 551));
        verticalLayout = new QVBoxLayout(layoutWidget_3);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_5 = new QPushButton(layoutWidget_3);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);

        pushButton_4 = new QPushButton(layoutWidget_3);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_3 = new QPushButton(layoutWidget_3);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton_6 = new QPushButton(layoutWidget_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        verticalLayout->addWidget(pushButton_6);

        pushButton_9 = new QPushButton(layoutWidget_3);
        pushButton_9->setObjectName(QString::fromUtf8("pushButton_9"));

        verticalLayout->addWidget(pushButton_9);

        pushButton_10 = new QPushButton(layoutWidget_3);
        pushButton_10->setObjectName(QString::fromUtf8("pushButton_10"));

        verticalLayout->addWidget(pushButton_10);

        textBrowser = new QTextBrowser(Dialog);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(30, 50, 741, 521));
        label_27 = new QLabel(Dialog);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(810, 60, 161, 31));
        pushButton = new QPushButton(Dialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(780, 510, 231, 51));

        retranslateUi(Dialog);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        pushButton_8->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "PenWidth:", nullptr));
        label_6->setText(QCoreApplication::translate("Dialog", "PenStyle:", nullptr));
        label_7->setText(QCoreApplication::translate("Dialog", "PenCap:", nullptr));
        label_8->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        pushButton_11->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label_9->setText(QCoreApplication::translate("Dialog", "Font Size:", nullptr));
        label_10->setText(QCoreApplication::translate("Dialog", "Font Style:", nullptr));
        label_11->setText(QCoreApplication::translate("Dialog", "Font Family:", nullptr));
        label_12->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        pushButton_12->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label_13->setText(QCoreApplication::translate("Dialog", "PenWidth:", nullptr));
        label_14->setText(QCoreApplication::translate("Dialog", "PenStyle:", nullptr));
        label_15->setText(QCoreApplication::translate("Dialog", "PenCap:", nullptr));
        label_16->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        pushButton_13->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label_17->setText(QCoreApplication::translate("Dialog", "PenWidth:", nullptr));
        label_18->setText(QCoreApplication::translate("Dialog", "PenStyle:", nullptr));
        label_19->setText(QCoreApplication::translate("Dialog", "PenCap:", nullptr));
        label_20->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        label_25->setText(QCoreApplication::translate("Dialog", "FillColor", nullptr));
        label_26->setText(QCoreApplication::translate("Dialog", "FillStyle", nullptr));
        pushButton_14->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label_21->setText(QCoreApplication::translate("Dialog", "PenWidth:", nullptr));
        label_22->setText(QCoreApplication::translate("Dialog", "PenStyle:", nullptr));
        label_23->setText(QCoreApplication::translate("Dialog", "PenCap:", nullptr));
        label_24->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        pushButton_7->setText(QCoreApplication::translate("Dialog", "Build", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "PenWidth:", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "PenStyle:", nullptr));
        label_4->setText(QCoreApplication::translate("Dialog", "PenCap:", nullptr));
        label_5->setText(QCoreApplication::translate("Dialog", "PenJoin:", nullptr));
        pushButton_5->setText(QCoreApplication::translate("Dialog", "Line", nullptr));
        pushButton_4->setText(QCoreApplication::translate("Dialog", "Text", nullptr));
        pushButton_3->setText(QCoreApplication::translate("Dialog", "Rectangle", nullptr));
        pushButton_6->setText(QCoreApplication::translate("Dialog", "Polygon", nullptr));
        pushButton_9->setText(QCoreApplication::translate("Dialog", "Ellipse", nullptr));
        pushButton_10->setText(QCoreApplication::translate("Dialog", "Polyline", nullptr));
        textBrowser->setHtml(QCoreApplication::translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Gulim'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Render Area. This should be handled by a class, RenderArea, which has an ability to draw shpaes.</p></body></html>", nullptr));
        label_27->setText(QCoreApplication::translate("Dialog", "<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; font-weight:600;\">WillGetanA</span></p></body></html>", nullptr));
        pushButton->setText(QCoreApplication::translate("Dialog", "Save", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOG_H
