/********************************************************************************
** Form generated from reading UI file 'paint.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PAINT_H
#define UI_PAINT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_paint
{
public:
    QStackedWidget *stackwidget;
    QWidget *Polygon;
    QWidget *layoutWidget_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_8;
    QVBoxLayout *verticalLayout_4;
    QLineEdit *lineEdit_2;
    QComboBox *comboBox_4;
    QComboBox *comboBox_5;
    QComboBox *comboBox_6;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QWidget *Line;
    QWidget *layoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_7;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QWidget *page;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QPushButton *pushButton_6;
    QPushButton *pushButton_2;

    void setupUi(QDialog *paint)
    {
        if (paint->objectName().isEmpty())
            paint->setObjectName(QString::fromUtf8("paint"));
        paint->resize(1163, 710);
        stackwidget = new QStackedWidget(paint);
        stackwidget->setObjectName(QString::fromUtf8("stackwidget"));
        stackwidget->setGeometry(QRect(650, 100, 421, 441));
        Polygon = new QWidget();
        Polygon->setObjectName(QString::fromUtf8("Polygon"));
        layoutWidget_2 = new QWidget(Polygon);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(180, 20, 231, 401));
        gridLayout_2 = new QGridLayout(layoutWidget_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButton_8 = new QPushButton(layoutWidget_2);
        pushButton_8->setObjectName(QString::fromUtf8("pushButton_8"));

        gridLayout_2->addWidget(pushButton_8, 1, 0, 1, 2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        lineEdit_2 = new QLineEdit(layoutWidget_2);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        verticalLayout_4->addWidget(lineEdit_2);

        comboBox_4 = new QComboBox(layoutWidget_2);
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));

        verticalLayout_4->addWidget(comboBox_4);

        comboBox_5 = new QComboBox(layoutWidget_2);
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));

        verticalLayout_4->addWidget(comboBox_5);

        comboBox_6 = new QComboBox(layoutWidget_2);
        comboBox_6->setObjectName(QString::fromUtf8("comboBox_6"));

        verticalLayout_4->addWidget(comboBox_6);


        gridLayout_2->addLayout(verticalLayout_4, 0, 1, 1, 1);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        label_5 = new QLabel(layoutWidget_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_5->addWidget(label_5);

        label_6 = new QLabel(layoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_5->addWidget(label_6);

        label_7 = new QLabel(layoutWidget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_5->addWidget(label_7);

        label_8 = new QLabel(layoutWidget_2);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_5->addWidget(label_8);


        gridLayout_2->addLayout(verticalLayout_5, 0, 0, 1, 1);

        stackwidget->addWidget(Polygon);
        Line = new QWidget();
        Line->setObjectName(QString::fromUtf8("Line"));
        layoutWidget = new QWidget(Line);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(180, 20, 231, 401));
        gridLayout = new QGridLayout(layoutWidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_7 = new QPushButton(layoutWidget);
        pushButton_7->setObjectName(QString::fromUtf8("pushButton_7"));

        gridLayout->addWidget(pushButton_7, 1, 0, 1, 2);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        verticalLayout_2->addWidget(lineEdit);

        comboBox = new QComboBox(layoutWidget);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        verticalLayout_2->addWidget(comboBox);

        comboBox_2 = new QComboBox(layoutWidget);
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));

        verticalLayout_2->addWidget(comboBox_2);

        comboBox_3 = new QComboBox(layoutWidget);
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));

        verticalLayout_2->addWidget(comboBox_3);


        gridLayout->addLayout(verticalLayout_2, 0, 1, 1, 1);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_3->addWidget(label);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_3->addWidget(label_2);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_3->addWidget(label_3);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_3->addWidget(label_4);


        gridLayout->addLayout(verticalLayout_3, 0, 0, 1, 1);

        stackwidget->addWidget(Line);
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        stackwidget->addWidget(page);
        layoutWidget1 = new QWidget(paint);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(1080, 30, 77, 551));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_5 = new QPushButton(layoutWidget1);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));

        verticalLayout->addWidget(pushButton_5);

        pushButton_4 = new QPushButton(layoutWidget1);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));

        verticalLayout->addWidget(pushButton_4);

        pushButton_3 = new QPushButton(layoutWidget1);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        verticalLayout->addWidget(pushButton_3);

        pushButton = new QPushButton(layoutWidget1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout->addWidget(pushButton);

        pushButton_6 = new QPushButton(layoutWidget1);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));

        verticalLayout->addWidget(pushButton_6);

        pushButton_2 = new QPushButton(layoutWidget1);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        verticalLayout->addWidget(pushButton_2);


        retranslateUi(paint);
        QObject::connect(pushButton_5, SIGNAL(clicked()), paint, SLOT(open()));

        stackwidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(paint);
    } // setupUi

    void retranslateUi(QDialog *paint)
    {
        paint->setWindowTitle(QCoreApplication::translate("paint", "Dialog", nullptr));
        pushButton_8->setText(QCoreApplication::translate("paint", "Build", nullptr));
        label_5->setText(QCoreApplication::translate("paint", "PenWidth:", nullptr));
        label_6->setText(QCoreApplication::translate("paint", "PenStyle:", nullptr));
        label_7->setText(QCoreApplication::translate("paint", "PenCap:", nullptr));
        label_8->setText(QCoreApplication::translate("paint", "PenJoin:", nullptr));
        pushButton_7->setText(QCoreApplication::translate("paint", "Build", nullptr));
        label->setText(QCoreApplication::translate("paint", "PenWidth:", nullptr));
        label_2->setText(QCoreApplication::translate("paint", "PenStyle:", nullptr));
        label_3->setText(QCoreApplication::translate("paint", "PenCap:", nullptr));
        label_4->setText(QCoreApplication::translate("paint", "PenJoin:", nullptr));
        pushButton_5->setText(QCoreApplication::translate("paint", "Line", nullptr));
        pushButton_4->setText(QCoreApplication::translate("paint", "Text", nullptr));
        pushButton_3->setText(QCoreApplication::translate("paint", "Rectangle", nullptr));
        pushButton->setText(QCoreApplication::translate("paint", "Polygon", nullptr));
        pushButton_6->setText(QCoreApplication::translate("paint", "Elipse", nullptr));
        pushButton_2->setText(QCoreApplication::translate("paint", "Polyline", nullptr));
    } // retranslateUi

};

namespace Ui {
    class paint: public Ui_paint {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PAINT_H
