#include <iostream>
#include <string>
#include "Text.h"

using std::string;
using std::cout;
using std::cin;

void Text::GetText()
{
    string word;
    shapeId = 8;
    shapeType = "Text";

    cout << "What Color do you want the shape to be: ";
    getline(cin,word);
    shapeColor = QString::fromStdString(word);

    cout << "What TextAlignment do you want the text to have: ";
    getline(cin,word);
    textAli = QString::fromStdString(word);

    cout << "What Size do you want the text to be: ";
    cin  >> textPointSize;

    cout << "What FontFamily do you want the text to have: ";
    getline(cin,word);
    fontFamily = QString::fromStdString(word);

    cout << "What FontStyle do you want the text to have: ";
    getline(cin,word);
    fontStyle = QString::fromStdString(word);

    cout << "What FontWeight do you want the text to have: ";
    getline(cin,word);
    fontWeight = QString::fromStdString(word);

    cout << "What do you want the text to say: ";
    getline(cin,word);
    textString = QString::fromStdString(word);
    //********* set dimentions here ******************
}
