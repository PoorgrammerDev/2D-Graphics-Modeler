#ifndef RENDERAREA_H
#define RENDERAREA_H


class RenderArea
{
public:
    RenderArea();
};

#endif // RENDERAREA_H
