#include "renderarea.h"

RenderArea::RenderArea()
{

}
